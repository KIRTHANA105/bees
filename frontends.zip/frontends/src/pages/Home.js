import React from "react";
import { Link } from "react-router-dom";

const Home = () => (
  <div style={{ textAlign: "center", marginTop: "50px" }}>
    <h1>Welcome to Alzheimer Prediction App</h1>
    <Link to="/login">Login</Link>
  </div>
);

export default Home;
