import React from "react";

const Dashboard = () => (
  <div style={{ textAlign: "center", marginTop: "50px" }}>
    <h1>Dashboard</h1>
    <p>This is just a placeholder. After login, go to Upload page.</p>
  </div>
);

export default Dashboard;
