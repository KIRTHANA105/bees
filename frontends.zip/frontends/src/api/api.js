import axios from 'axios';

const API = axios.create({
  baseURL: "http://localhost:5000"
});

export const uploadImage = async (file) => {
  const formData = new FormData();
  formData.append("file", file);
  const res = await API.post("/predict", formData, {
    headers: { "Content-Type": "multipart/form-data" }
  });
  return res.data;
};
