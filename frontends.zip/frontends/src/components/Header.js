import React from "react";

export default function Header() {
  return (
    <header style={{ padding: "1rem", background: "#0b5", color: "#012" }}>
      <h1>Bees Classifier</h1>
    </header>
  );
}
