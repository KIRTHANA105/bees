import React from "react";

export default function Footer() {
  return (
    <footer style={{ padding: "1rem", textAlign: "center" }}>
      <small>© 2025 Bees Project</small>
    </footer>
  );
}
